//alert para o botao sim

function alertYes(){
    alert("Obrigada por prestar atenção na aula!")
}